lsnrctl status
